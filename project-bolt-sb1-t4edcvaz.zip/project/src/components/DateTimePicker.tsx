import React from 'react';
import DatePicker from 'react-datepicker';
import { useDispatch, useSelector } from 'react-redux';
import { setDate, setTimeOfDay } from '../store/slices/filtersSlice';
import { RootState } from '../store';
import "react-datepicker/dist/react-datepicker.css";
import { Clock } from 'lucide-react';

const DateTimePicker: React.FC = () => {
  const dispatch = useDispatch();
  const { date, timeOfDay } = useSelector((state: RootState) => state.filters);

  const handleDateChange = (date: Date | null) => {
    dispatch(setDate(date));
  };

  const handleTimeChange = (time: string) => {
    dispatch(setTimeOfDay(time));
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col">
        <label className="text-sm font-medium text-gray-700 mb-1">Select Date</label>
        <DatePicker
          selected={date}
          onChange={handleDateChange}
          dateFormat="MMMM d, yyyy"
          minDate={new Date()}
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholderText="Choose your travel date"
        />
      </div>

      <div className="flex flex-col">
        <label className="text-sm font-medium text-gray-700 mb-1">Time of Day</label>
        <div className="grid grid-cols-3 gap-2">
          {['morning', 'afternoon', 'evening'].map((time) => (
            <button
              key={time}
              onClick={() => handleTimeChange(time)}
              className={`flex items-center justify-center px-4 py-2 rounded-md text-sm font-medium capitalize
                ${timeOfDay === time
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              <Clock className="w-4 h-4 mr-2" />
              {time}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DateTimePicker;
import React from 'react';
import { Cloud, Sun, CloudRain } from 'lucide-react';
import { WeatherInfo } from '../types';

const mockWeather: WeatherInfo = {
  temperature: 28,
  condition: 'Partly Cloudy',
  icon: 'cloud',
};

const WeatherWidget: React.FC = () => {
  const getWeatherIcon = (icon: string) => {
    switch (icon) {
      case 'sun':
        return <Sun className="w-8 h-8 text-yellow-500" />;
      case 'rain':
        return <CloudRain className="w-8 h-8 text-gray-600" />;
      default:
        return <Cloud className="w-8 h-8 text-gray-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          {getWeatherIcon(mockWeather.icon)}
          <div className="ml-3">
            <p className="text-2xl font-bold">{mockWeather.temperature}°C</p>
            <p className="text-gray-600">{mockWeather.condition}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500">Phayao, Thailand</p>
          <p className="text-xs text-gray-400">Updated: {new Date().toLocaleTimeString()}</p>
        </div>
      </div>
    </div>
  );
};

export default WeatherWidget;
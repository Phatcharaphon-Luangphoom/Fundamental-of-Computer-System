import React from 'react';
import { Clock, MapPin, Star } from 'lucide-react';
import { Attraction } from '../types';

interface AttractionCardProps {
  attraction: Attraction;
}

const AttractionCard: React.FC<AttractionCardProps> = ({ attraction }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img
        src={attraction.imageUrl}
        alt={attraction.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-2">{attraction.name}</h3>
        <div className="flex items-center mb-2">
          <Star className="w-4 h-4 text-yellow-400 mr-1" />
          <span className="text-gray-600">{attraction.rating.toFixed(1)}</span>
        </div>
        <p className="text-gray-600 mb-4">{attraction.description}</p>
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center">
            <Clock className="w-4 h-4 mr-1" />
            <span>{attraction.duration}h</span>
          </div>
          <div className="flex items-center">
            <MapPin className="w-4 h-4 mr-1" />
            <span>{attraction.priceRange}</span>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {attraction.category.map((cat) => (
            <span
              key={cat}
              className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
            >
              {cat}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AttractionCard;
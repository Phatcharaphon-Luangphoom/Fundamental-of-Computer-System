export interface Attraction {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  category: string[];
  bestTimeToVisit: string[];
  duration: number; // in hours
  location: {
    lat: number;
    lng: number;
  };
  rating: number;
  priceRange: string;
}

export interface TravelPlan {
  date: Date;
  timeOfDay: 'morning' | 'afternoon' | 'evening';
  attractions: Attraction[];
}

export interface WeatherInfo {
  temperature: number;
  condition: string;
  icon: string;
}

export interface FilterState {
  categories: string[];
  timeOfDay: string | null;
  date: Date | null;
}
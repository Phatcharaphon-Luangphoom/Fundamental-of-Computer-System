import React from 'react';
import { Provider } from 'react-redux';
import { store } from './store';
import DateTimePicker from './components/DateTimePicker';
import WeatherWidget from './components/WeatherWidget';
import AttractionCard from './components/AttractionCard';
import { Compass } from 'lucide-react';

// Mock data - in a real app, this would come from Supabase
const mockAttractions = [
  {
    id: '1',
    name: 'Kwan Phayao',
    description: 'The largest fresh-water lake in Northern Thailand, offering stunning sunset views and local fishing culture.',
    imageUrl: 'https://images.unsplash.com/photo-1528181304800-259b08848526?auto=format&fit=crop&q=80&w=1200',
    category: ['Nature', 'Culture'],
    bestTimeToVisit: ['morning', 'evening'],
    duration: 2,
    location: {
      lat: 19.1725,
      lng: 99.9003
    },
    rating: 4.5,
    priceRange: 'Free'
  },
  {
    id: '2',
    name: 'Wat Si Khom Kham',
    description: 'Ancient temple featuring a massive sitting Buddha statue and beautiful architecture.',
    imageUrl: 'https://images.unsplash.com/photo-1528181304800-259b08848526?auto=format&fit=crop&q=80&w=1200',
    category: ['Temple', 'Culture'],
    bestTimeToVisit: ['morning', 'afternoon'],
    duration: 1.5,
    location: {
      lat: 19.1697,
      lng: 99.9082
    },
    rating: 4.7,
    priceRange: 'Free'
  }
];

function App() {
  return (
    <Provider store={store}>
      <div className="min-h-screen bg-gray-100">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Compass className="w-8 h-8 text-blue-500" />
                <h1 className="ml-2 text-2xl font-bold text-gray-900">Phayao Travel Guide</h1>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-6">
              <WeatherWidget />
              <div className="bg-white rounded-lg shadow-md p-4">
                <h2 className="text-lg font-semibold mb-4">Plan Your Visit</h2>
                <DateTimePicker />
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {mockAttractions.map((attraction) => (
                  <AttractionCard key={attraction.id} attraction={attraction} />
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </Provider>
  );
}

export default App;
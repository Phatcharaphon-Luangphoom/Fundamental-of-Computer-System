import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { FilterState } from '../../types';

const initialState: FilterState = {
  categories: [],
  timeOfDay: null,
  date: null,
};

const filtersSlice = createSlice({
  name: 'filters',
  initialState,
  reducers: {
    setCategories: (state, action: PayloadAction<string[]>) => {
      state.categories = action.payload;
    },
    setTimeOfDay: (state, action: PayloadAction<string | null>) => {
      state.timeOfDay = action.payload;
    },
    setDate: (state, action: PayloadAction<Date | null>) => {
      state.date = action.payload;
    },
    resetFilters: (state) => {
      state.categories = [];
      state.timeOfDay = null;
      state.date = null;
    },
  },
});

export const { setCategories, setTimeOfDay, setDate, resetFilters } = filtersSlice.actions;
export default filtersSlice.reducer;
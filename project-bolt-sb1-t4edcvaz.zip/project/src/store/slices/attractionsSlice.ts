import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Attraction } from '../../types';

interface AttractionsState {
  items: Attraction[];
  loading: boolean;
  error: string | null;
}

const initialState: AttractionsState = {
  items: [],
  loading: false,
  error: null,
};

const attractionsSlice = createSlice({
  name: 'attractions',
  initialState,
  reducers: {
    setAttractions: (state, action: PayloadAction<Attraction[]>) => {
      state.items = action.payload;
      state.loading = false;
      state.error = null;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state, action: PayloadAction<string>) => {
      state.error = action.payload;
      state.loading = false;
    },
  },
});

export const { setAttractions, setLoading, setError } = attractionsSlice.actions;
export default attractionsSlice.reducer;
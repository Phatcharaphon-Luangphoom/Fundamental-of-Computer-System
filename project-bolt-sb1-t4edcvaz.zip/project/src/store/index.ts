import { configureStore } from '@reduxjs/toolkit';
import filtersReducer from './slices/filtersSlice';
import attractionsReducer from './slices/attractionsSlice';

export const store = configureStore({
  reducer: {
    filters: filtersReducer,
    attractions: attractionsReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;